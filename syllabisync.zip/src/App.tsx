import { useState, useEffect } from "react";
import { 
  LayoutDashboard, 
  BookOpen, 
  Calendar, 
  PlusCircle, 
  Settings as SettingsIcon,
  Calculator,
  ChevronRight,
  Menu,
  X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Class, Assignment, Lecture } from "./types";
import SyllabusImporter from "./components/SyllabusImporter";
import ClassDashboard from "./components/ClassDashboard";
import GlobalDashboard from "./components/GlobalDashboard";
import GradeCalculator from "./components/GradeCalculator";
import CalendarView from "./components/CalendarView";

export default function App() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "classes" | "calendar" | "grades" | "settings">("dashboard");
  const [classes, setClasses] = useState<Class[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [lectures, setLectures] = useState<Lecture[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isImporterOpen, setIsImporterOpen] = useState(false);

  useEffect(() => {
    fetchData();
    testApi();
  }, []);

  const testApi = async () => {
    try {
      const res = await fetch("/api/test");
      const data = await res.json();
      console.log("API Test:", data);
    } catch (err) {
      console.error("API Test failed:", err);
    }
  };

  const fetchData = async () => {
    try {
      const [classesRes, assignmentsRes, lecturesRes] = await Promise.all([
        fetch("/api/classes"),
        fetch("/api/assignments"),
        fetch("/api/lectures")
      ]);
      const classesData = await classesRes.json();
      const assignmentsData = await assignmentsRes.json();
      const lecturesData = await lecturesRes.json();
      setClasses(classesData);
      setAssignments(assignmentsData);
      setLectures(lecturesData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleClassAdded = async (newClass: Class) => {
    await fetchData();
    setSelectedClassId(newClass.id);
    setActiveTab("classes");
  };

  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "classes", label: "My Classes", icon: BookOpen },
    { id: "grades", label: "Grades", icon: Calculator },
    { id: "calendar", label: "Calendar", icon: Calendar },
    { id: "settings", label: "Settings", icon: SettingsIcon },
  ];

  return (
    <div className="flex h-screen bg-navy-50 overflow-hidden">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 260 : 80 }}
        className="bg-navy-900 text-white flex flex-col shadow-xl z-20"
      >
        <div className="p-6 flex items-center justify-between">
          {isSidebarOpen && (
            <motion.h1 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xl font-bold tracking-tight text-white"
            >
              Syllabi<span className="text-navy-300">Sync</span>
            </motion.h1>
          )}
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-1 hover:bg-navy-800 rounded-lg transition-colors"
          >
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all ${
                activeTab === item.id 
                  ? "bg-navy-700 text-white shadow-lg" 
                  : "text-navy-300 hover:bg-navy-800 hover:text-white"
              }`}
            >
              <item.icon size={20} />
              {isSidebarOpen && <span className="font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-navy-800">
          <button 
            onClick={() => setIsImporterOpen(true)}
            className="w-full flex items-center gap-3 px-3 py-3 text-navy-400 hover:text-white transition-colors"
          >
            <PlusCircle size={20} />
            {isSidebarOpen && <span className="text-sm font-medium">Import Syllabus</span>}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 bg-white border-b border-navy-100 flex items-center justify-between px-8">
          <h2 className="text-lg font-semibold text-navy-900 capitalize">
            {activeTab === "classes" && selectedClassId 
              ? classes.find(c => c.id === selectedClassId)?.name 
              : activeTab}
          </h2>
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 rounded-full bg-navy-200 flex items-center justify-center text-navy-700 font-bold text-xs">
              JD
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab + (selectedClassId || "")}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="max-w-7xl mx-auto"
            >
              {activeTab === "dashboard" && (
                <GlobalDashboard 
                  classes={classes} 
                  assignments={assignments} 
                  lectures={lectures}
                  onImportClick={() => setIsImporterOpen(true)}
                />
              )}

              {activeTab === "classes" && (
                <ClassDashboard 
                  classes={classes}
                  selectedClassId={selectedClassId}
                  setSelectedClassId={setSelectedClassId}
                  assignments={assignments}
                  onAssignmentsUpdate={fetchData}
                />
              )}

              {activeTab === "grades" && (
                <GradeCalculator 
                  classes={classes}
                  assignments={assignments}
                  onAssignmentsUpdate={fetchData}
                />
              )}

              {activeTab === "calendar" && (
                <CalendarView 
                  classes={classes}
                  assignments={assignments}
                  lectures={lectures}
                />
              )}

              {activeTab === "settings" && (
                <div className="max-w-2xl bg-white p-8 rounded-3xl shadow-sm border border-navy-100">
                  <h3 className="text-xl font-bold text-navy-900 mb-6">Settings</h3>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between p-4 bg-navy-50 rounded-2xl">
                      <div>
                        <p className="font-semibold">Dark Mode</p>
                        <p className="text-sm text-navy-500">Enable dark theme for the app</p>
                      </div>
                      <div className="w-12 h-6 bg-navy-200 rounded-full relative">
                        <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-navy-50 rounded-2xl">
                      <div>
                        <p className="font-semibold">Notifications</p>
                        <p className="text-sm text-navy-500">Get reminders for upcoming deadlines</p>
                      </div>
                      <div className="w-12 h-6 bg-navy-900 rounded-full relative">
                        <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Syllabus Importer Overlay */}
          <SyllabusImporter 
            onClassAdded={handleClassAdded}
            onClose={() => setIsImporterOpen(false)}
            openOverride={isImporterOpen}
            setOpenOverride={setIsImporterOpen}
          />
        </div>
      </main>
    </div>
  );
}
