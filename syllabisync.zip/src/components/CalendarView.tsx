import { useState } from "react";
import { Class, Assignment, Lecture } from "../types";
import { 
  ChevronLeft, 
  ChevronRight, 
  Download, 
  Calendar as CalendarIcon,
  ExternalLink,
  Plus,
  Clock,
  MapPin,
  ClipboardCheck,
  Bell,
  AlertCircle,
  Maximize2,
  Minimize2,
  X as CloseIcon
} from "lucide-react";
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isSameMonth, 
  isSameDay, 
  addDays,
  parseISO,
  isValid
} from "date-fns";
import { motion, AnimatePresence } from "motion/react";

interface CalendarViewProps {
  classes: Class[];
  assignments: Assignment[];
  lectures: Lecture[];
}

export default function CalendarView({ classes, assignments, lectures }: CalendarViewProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isFullScreen, setIsFullScreen] = useState(false);

  const AssignmentIcon = ({ color, size = 20 }: { color: string, size?: number }) => (
    <div className="relative" style={{ color }}>
      <ClipboardCheck size={size} />
      <div className="absolute -top-1 -right-1 flex items-center justify-center">
        <div className="w-2.5 h-2.5 bg-white rounded-full flex items-center justify-center">
          <AlertCircle size={size * 0.5} className="text-red-500 fill-red-500" />
        </div>
      </div>
    </div>
  );

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 1 });
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 });

  const calendarDays = eachDayOfInterval({
    start: startDate,
    end: endDate,
  });

  const getAssignmentsForDay = (day: Date) => {
    return assignments.filter(a => {
      if (!a.due_date) return false;
      // Use a more robust parsing approach
      let d = parseISO(a.due_date);
      if (!isValid(d)) {
        d = new Date(a.due_date);
      }
      return isValid(d) && isSameDay(d, day);
    });
  };

  const getLecturesForDay = (day: Date) => {
    const dayName = format(day, "EEEE");
    return lectures.filter(l => l.day_of_week === dayName);
  };

  const CalendarContent = ({ fullScreen = false }: { fullScreen?: boolean }) => (
    <div className={`grid grid-cols-1 ${fullScreen ? "lg:grid-cols-5" : "lg:grid-cols-4"} gap-8 h-full`}>
      {/* Calendar Grid */}
      <div className={`${fullScreen ? "lg:col-span-4" : "lg:col-span-3"} bg-white rounded-3xl shadow-sm border border-navy-100 overflow-hidden flex flex-col`}>
        <div className="p-6 border-b border-navy-100 flex items-center justify-between">
          <h3 className="text-xl font-bold text-navy-900">
            {format(currentMonth, "MMMM yyyy")}
          </h3>
          <div className="flex items-center gap-2">
            <button 
              onClick={prevMonth}
              className="p-2 hover:bg-navy-50 rounded-xl text-navy-400 hover:text-navy-900 transition-all"
            >
              <ChevronLeft size={20} />
            </button>
            <button 
              onClick={() => setCurrentMonth(new Date())}
              className="px-4 py-2 text-sm font-bold text-navy-600 hover:bg-navy-50 rounded-xl transition-all"
            >
              Today
            </button>
            <button 
              onClick={nextMonth}
              className="p-2 hover:bg-navy-50 rounded-xl text-navy-400 hover:text-navy-900 transition-all"
            >
              <ChevronRight size={20} />
            </button>
            {!fullScreen && (
              <button 
                onClick={() => setIsFullScreen(true)}
                className="p-2 hover:bg-navy-50 rounded-xl text-navy-400 hover:text-navy-900 transition-all ml-2"
                title="Full Screen"
              >
                <Maximize2 size={20} />
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-7 border-b border-navy-50">
          {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(day => (
            <div key={day} className="py-3 text-center text-[10px] font-bold uppercase tracking-widest text-navy-300">
              {day}
            </div>
          ))}
        </div>

        <div className={`grid grid-cols-7 flex-1 ${fullScreen ? "auto-rows-auto min-h-[900px]" : "auto-rows-[120px]"}`}>
          {calendarDays.map((day, idx) => {
            const dayAssignments = getAssignmentsForDay(day);
            const dayLectures = getLecturesForDay(day);
            const isSelected = isSameDay(day, selectedDate);
            const isCurrentMonth = isSameMonth(day, monthStart);
            const isToday = isSameDay(day, new Date());

            return (
              <div 
                key={idx}
                onClick={() => setSelectedDate(day)}
                className={`p-2 border-r border-b border-navy-50 transition-all cursor-pointer group hover:bg-navy-50/50 ${
                  !isCurrentMonth ? "bg-navy-50/30" : ""
                } ${isSelected ? "bg-navy-50/80 ring-2 ring-inset ring-navy-900/10" : ""}`}
              >
                <div className="flex justify-between items-start mb-1">
                  <span className={`text-sm font-bold w-7 h-7 flex items-center justify-center rounded-lg transition-all ${
                    isToday ? "bg-navy-900 text-white shadow-md" : 
                    isCurrentMonth ? "text-navy-900" : "text-navy-300"
                  }`}>
                    {format(day, "d")}
                  </span>
                  <div className="flex gap-1">
                    {dayAssignments.length > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-navy-900" />
                    )}
                    {dayLectures.length > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    )}
                  </div>
                </div>
                <div className="space-y-1 overflow-hidden">
                  {dayLectures.map(l => {
                    const course = classes.find(c => c.id === l.class_id);
                    return (
                      <div 
                        key={l.id}
                        className="px-1.5 py-0.5 rounded-md text-[8px] font-bold truncate bg-emerald-50 text-emerald-700 border-l-2 border-emerald-500"
                      >
                        {l.start_time} {course?.name}
                      </div>
                    );
                  })}
                  {dayAssignments.slice(0, fullScreen ? 4 : 2).map(a => {
                    const course = classes.find(c => c.id === a.class_id);
                    return (
                      <div 
                        key={a.id}
                        className="px-1.5 py-1 rounded-lg text-[8px] font-bold truncate border shadow-sm flex items-center gap-1"
                        style={{ 
                          backgroundColor: `${course?.color}10`, 
                          color: course?.color,
                          borderColor: `${course?.color}30`
                        }}
                      >
                        <AssignmentIcon color={course?.color || "#000"} size={10} />
                        <span className="truncate">
                          <span className="opacity-60 mr-1">{course?.name}:</span>
                          {a.name}
                        </span>
                      </div>
                    );
                  })}
                  {dayAssignments.length > (fullScreen ? 4 : 2) && (
                    <p className="text-[8px] font-bold text-navy-400 pl-1">
                      + {dayAssignments.length - (fullScreen ? 4 : 2)} more
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Day Detail Sidebar */}
      <div className="space-y-6 overflow-y-auto pr-2 custom-scrollbar">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-navy-100">
          <div className="flex items-center justify-between mb-6">
            <h4 className="font-bold text-navy-900">
              {format(selectedDate, "EEEE, MMM d")}
            </h4>
            <div className="w-8 h-8 bg-navy-50 rounded-xl flex items-center justify-center text-navy-400">
              <CalendarIcon size={16} />
            </div>
          </div>

          <div className="space-y-4">
            {/* Lectures Section */}
            {getLecturesForDay(selectedDate).length > 0 && (
              <div className="space-y-3">
                <p className="text-[10px] font-bold text-navy-400 uppercase tracking-widest">Lectures</p>
                {getLecturesForDay(selectedDate).map(l => {
                  const course = classes.find(c => c.id === l.class_id);
                  return (
                    <motion.div 
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      key={l.id} 
                      className="p-4 rounded-2xl border border-emerald-100 bg-emerald-50/30 space-y-2"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-emerald-500" />
                        <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">
                          {course?.name}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-navy-700">
                          <Clock size={12} className="text-navy-400" />
                          <span className="text-xs font-bold">{l.start_time} - {l.end_time}</span>
                        </div>
                        {l.location && (
                          <div className="flex items-center gap-1.5 text-navy-500">
                            <MapPin size={12} className="text-navy-400" />
                            <span className="text-[10px] font-medium">{l.location}</span>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* Assignments Section */}
            <div className="space-y-3">
              <p className="text-[10px] font-bold text-navy-400 uppercase tracking-widest">Assignments</p>
              {getAssignmentsForDay(selectedDate).length > 0 ? (
                getAssignmentsForDay(selectedDate).map(a => {
                  const course = classes.find(c => c.id === a.class_id);
                  return (
                    <motion.div 
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      key={a.id} 
                      className="p-4 rounded-2xl border border-navy-100 bg-navy-50/30 space-y-3"
                    >
                      <div className="flex items-start gap-3">
                        <div className="mt-1">
                          <AssignmentIcon color={course?.color || "#000"} size={18} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: course?.color }} />
                            <span className="text-[10px] font-bold text-navy-400 uppercase tracking-wider truncate">
                              {course?.name}
                            </span>
                          </div>
                          <h5 className="font-bold text-navy-900 text-sm leading-tight">{a.name}</h5>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[10px] font-medium text-navy-500">
                          Due {(() => {
                            const d = parseISO(a.due_date!);
                            return isValid(d) ? format(d, "h:mm a") : a.due_date;
                          })()}
                        </span>
                        <span className={`px-2 py-0.5 rounded-lg text-[9px] font-bold ${
                          a.priority === "Critical" ? "bg-red-100 text-red-700" :
                          a.priority === "High" ? "bg-orange-100 text-orange-700" :
                          "bg-navy-100 text-navy-700"
                        }`}>
                          {a.priority}
                        </span>
                      </div>
                    </motion.div>
                  );
                })
              ) : (
                <div className="py-8 text-center border-2 border-dashed border-navy-50 rounded-2xl">
                  <p className="text-xs font-medium text-navy-300">No assignments due today.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-navy-900 text-white p-6 rounded-3xl shadow-xl">
          <h4 className="font-bold mb-2">Calendar Sync</h4>
          <p className="text-xs text-navy-300 mb-4">
            Keep your assignments in sync with your favorite calendar apps.
          </p>
          <button 
            onClick={exportToICS}
            className="w-full py-3 bg-white text-navy-900 rounded-xl font-bold text-sm hover:bg-navy-50 transition-all flex items-center justify-center gap-2"
          >
            <Download size={16} />
            Download .ics
          </button>
        </div>
      </div>
    </div>
  );

  const exportToICS = () => {
    let icsContent = "BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//SyllabiSync//Assignment Calendar//EN\n";
    
    assignments.forEach(a => {
      if (!a.due_date) return;
      const date = parseISO(a.due_date);
      if (!isValid(date)) return; // Skip invalid dates for ICS export
      
      const course = classes.find(c => c.id === a.class_id);
      
      // Format date for ICS: YYYYMMDDTHHMMSSZ
      const formatICSDate = (d: Date) => d.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
      
      icsContent += "BEGIN:VEVENT\n";
      icsContent += `SUMMARY:${a.name} (${course?.name || "Unknown"})\n`;
      icsContent += `DTSTART:${formatICSDate(date)}\n`;
      icsContent += `DTEND:${formatICSDate(addDays(date, 0.04))}\n`; // 1 hour duration approx
      icsContent += `DESCRIPTION:Priority: ${a.priority}\\nWeight: ${a.weight}%\n`;
      icsContent += "END:VEVENT\n";
    });
    
    icsContent += "END:VCALENDAR";
    
    const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute("download", "assignments.ics");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const openGoogleCalendar = () => {
    alert("To export to Google Calendar:\n1. Download the .ics file using the 'Export as .ics' button.\n2. Go to Google Calendar Settings > Import & Export.\n3. Upload the downloaded file.");
  };

  const openOutlookCalendar = () => {
    alert("To export to Outlook Calendar:\n1. Download the .ics file using the 'Export as .ics' button.\n2. Open Outlook (Web or Desktop).\n3. Go to Calendar > Add Calendar > Upload from file.\n4. Select the downloaded assignments.ics file.");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-navy-900">Study Calendar</h2>
          <p className="text-navy-500">Visualize your deadlines and plan your study sessions.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex bg-white rounded-2xl border border-navy-100 p-1 shadow-sm">
            <button 
              onClick={exportToICS}
              className="flex items-center gap-2 px-4 py-2 hover:bg-navy-50 rounded-xl text-sm font-bold text-navy-700 transition-all"
            >
              <Download size={16} />
              Export .ics
            </button>
            <div className="w-px bg-navy-100 my-2" />
            <button 
              onClick={openGoogleCalendar}
              className="flex items-center gap-2 px-4 py-2 hover:bg-navy-50 rounded-xl text-sm font-bold text-navy-700 transition-all"
            >
              <ExternalLink size={16} />
              Google
            </button>
            <div className="w-px bg-navy-100 my-2" />
            <button 
              onClick={openOutlookCalendar}
              className="flex items-center gap-2 px-4 py-2 hover:bg-navy-50 rounded-xl text-sm font-bold text-navy-700 transition-all"
            >
              <ExternalLink size={16} />
              Outlook
            </button>
          </div>
        </div>
      </div>

      <CalendarContent />

      <AnimatePresence>
        {isFullScreen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-navy-50/95 backdrop-blur-sm p-4 md:p-8 overflow-y-auto custom-scrollbar"
          >
            <div className="max-w-[1600px] mx-auto min-h-full flex flex-col bg-white rounded-[40px] shadow-2xl border border-navy-100 overflow-hidden">
              <div className="p-6 md:p-8 border-b border-navy-100 flex items-center justify-between bg-white sticky top-0 z-20">
                <div>
                  <h2 className="text-2xl md:text-3xl font-bold text-navy-900">Study Calendar</h2>
                  <p className="text-navy-500 text-sm">Full Screen View</p>
                </div>
                <button 
                  onClick={() => setIsFullScreen(false)}
                  className="p-3 bg-navy-900 text-white hover:bg-navy-800 rounded-2xl transition-all flex items-center gap-2 font-bold shadow-lg"
                >
                  <Minimize2 size={20} />
                  <span className="hidden md:inline">Exit Full Screen</span>
                </button>
              </div>
              <div className="flex-1 p-6 md:p-8">
                <CalendarContent fullScreen={true} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
