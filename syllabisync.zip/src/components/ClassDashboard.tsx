import { useState } from "react";
import { Class, Assignment } from "../types";
import { 
  Plus, 
  Filter, 
  MoreVertical, 
  Calendar, 
  Clock, 
  CheckCircle, 
  Circle,
  AlertCircle,
  Trash2,
  Edit2,
  X,
  Loader2,
  Award,
  Check
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { format, isValid } from "date-fns";

const safeFormat = (dateStr: string | undefined, formatStr: string, fallback: string) => {
  if (!dateStr) return fallback;
  const date = new Date(dateStr);
  if (!isValid(date)) return dateStr; // Return raw string if it's something like "Week 6"
  return format(date, formatStr);
};

interface ClassDashboardProps {
  classes: Class[];
  selectedClassId: string | null;
  setSelectedClassId: (id: string | null) => void;
  assignments: Assignment[];
  onAssignmentsUpdate: () => void;
}

export default function ClassDashboard({ 
  classes, 
  selectedClassId, 
  setSelectedClassId, 
  assignments,
  onAssignmentsUpdate
}: ClassDashboardProps) {
  const [filter, setFilter] = useState<"all" | "active" | "done">("all");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [assignmentToDelete, setAssignmentToDelete] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [editingGradeId, setEditingGradeId] = useState<string | null>(null);
  const [tempGrade, setTempGrade] = useState<string>("");
  const [newAssignment, setNewAssignment] = useState<Partial<Assignment>>({
    name: "",
    due_date: new Date().toISOString().split("T")[0],
    weight: 10,
    category: "Assignment",
    priority: "Medium"
  });
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);

  const handleAddAssignment = async () => {
    if (!newAssignment.name || !selectedClassId) return;
    try {
      await fetch("/api/assignments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...newAssignment, class_id: selectedClassId, status: "not started" })
      });
      onAssignmentsUpdate();
      setIsAddModalOpen(false);
      setNewAssignment({
        name: "",
        due_date: new Date().toISOString().split("T")[0],
        weight: 10,
        category: "Assignment",
        priority: "Medium"
      });
    } catch (error) {
      console.error("Failed to add assignment", error);
    }
  };

  const handleEditAssignment = async () => {
    if (!editingAssignment) return;
    try {
      await fetch(`/api/assignments/${editingAssignment.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingAssignment)
      });
      onAssignmentsUpdate();
      setIsEditModalOpen(false);
      setEditingAssignment(null);
    } catch (error) {
      console.error("Failed to update assignment", error);
    }
  };

  const deleteAssignment = async (id: string) => {
    try {
      await fetch(`/api/assignments/${id}`, { method: "DELETE" });
      onAssignmentsUpdate();
      setAssignmentToDelete(null);
    } catch (error) {
      console.error("Failed to delete assignment", error);
    }
  };

  const handleDeleteClass = async () => {
    console.log("handleDeleteClass triggered for ID:", selectedClassId);
    if (!selectedClassId) return;
    
    setIsDeleting(true);
    try {
      const response = await fetch(`/api/classes/${selectedClassId}`, { 
        method: "DELETE",
        headers: { "Accept": "application/json" }
      });
      
      console.log("Delete response status:", response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to delete class");
      }
      
      const result = await response.json();
      console.log("Delete success result:", result);
      
      setIsDeleteModalOpen(false);
      setSelectedClassId(null);
      await onAssignmentsUpdate();
    } catch (error) {
      console.error("Critical error during class deletion:", error);
      alert(error instanceof Error ? error.message : "Failed to delete class. Please try again.");
    } finally {
      setIsDeleting(false);
    }
  };

  const isAllSelected = selectedClassId === null;
  const selectedClass = classes.find(c => c.id === selectedClassId);
  
  if (classes.length === 0) {
    return (
      <div className="text-center py-20">
        <h3 className="text-xl font-bold text-navy-900">No classes found.</h3>
        <p className="text-navy-500">Import a syllabus to get started.</p>
      </div>
    );
  }

  const classAssignments = assignments
    .filter(a => isAllSelected ? true : a.class_id === selectedClassId)
    .filter(a => {
      if (filter === "active") return a.status !== "done";
      if (filter === "done") return a.status === "done";
      return true;
    })
    .sort((a, b) => {
      if (!a.due_date) return 1;
      if (!b.due_date) return -1;
      const dateA = new Date(a.due_date).getTime();
      const dateB = new Date(b.due_date).getTime();
      if (isNaN(dateA)) return 1;
      if (isNaN(dateB)) return -1;
      return dateA - dateB;
    });

  const toggleStatus = async (assignment: Assignment) => {
    const newStatus = assignment.status === "done" ? "not started" : "done";
    try {
      await fetch(`/api/assignments/${assignment.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...assignment, status: newStatus })
      });
      
      // If marking as done and no grade exists, prompt for grade
      if (newStatus === "done" && (assignment.grade === undefined || assignment.grade === null)) {
        setEditingGradeId(assignment.id);
        setTempGrade("");
      }
      
      onAssignmentsUpdate();
    } catch (error) {
      console.error("Failed to update status", error);
    }
  };

  const handleSaveGrade = async (assignment: Assignment) => {
    const gradeVal = parseFloat(tempGrade);
    if (isNaN(gradeVal)) {
      setEditingGradeId(null);
      return;
    }

    try {
      await fetch(`/api/assignments/${assignment.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...assignment, grade: gradeVal, status: "done" })
      });
      setEditingGradeId(null);
      onAssignmentsUpdate();
    } catch (error) {
      console.error("Failed to save grade", error);
    }
  };

  return (
    <div className="space-y-8">
      {/* Class Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        <button
          onClick={() => setSelectedClassId(null)}
          className={`px-6 py-3 rounded-2xl font-bold whitespace-nowrap transition-all ${
            isAllSelected 
              ? "bg-navy-900 text-white shadow-lg scale-105" 
              : "bg-white text-navy-400 hover:bg-navy-50 border border-navy-100"
          }`}
        >
          All Classes
        </button>
        {classes.map(c => (
          <button
            key={c.id}
            onClick={() => setSelectedClassId(c.id)}
            className={`px-6 py-3 rounded-2xl font-bold whitespace-nowrap transition-all ${
              selectedClassId === c.id 
                ? "bg-navy-900 text-white shadow-lg scale-105" 
                : "bg-white text-navy-400 hover:bg-navy-50 border border-navy-100"
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>

      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h3 className="text-2xl font-bold text-navy-900">
              {isAllSelected ? "All Assignments" : selectedClass?.name}
            </h3>
            {!isAllSelected && (
              <button 
                onClick={() => {
                  console.log("Opening delete modal for class:", selectedClassId);
                  setIsDeleteModalOpen(true);
                }}
                className="p-2 text-navy-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                title="Delete Class"
              >
                <Trash2 size={18} />
              </button>
            )}
          </div>
          <p className="text-navy-500">
            {isAllSelected 
              ? "Viewing all assignments across your courses." 
              : "Manage your assignments and track your progress."}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-white p-1 rounded-2xl border border-navy-100 flex shadow-sm">
            {(["all", "active", "done"] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-xl text-sm font-bold capitalize transition-all ${
                  filter === f ? "bg-navy-900 text-white" : "text-navy-400 hover:text-navy-600"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          {!isAllSelected && (
            <button 
              onClick={() => setIsAddModalOpen(true)}
              className="bg-navy-900 text-white p-3 rounded-2xl shadow-lg hover:bg-navy-800 transition-all"
            >
              <Plus size={24} />
            </button>
          )}
        </div>
      </div>

      {/* Add Assignment Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddModalOpen(false)}
              className="absolute inset-0 bg-navy-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl p-8"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-navy-900">Add Assignment</h3>
                <button onClick={() => setIsAddModalOpen(false)} className="p-2 hover:bg-navy-50 rounded-full">
                  <X size={20} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Name</label>
                  <input 
                    type="text" 
                    value={newAssignment.name}
                    onChange={(e) => setNewAssignment({ ...newAssignment, name: e.target.value })}
                    className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    placeholder="Assignment Name"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Due Date</label>
                    <input 
                      type="date" 
                      value={newAssignment.due_date}
                      onChange={(e) => setNewAssignment({ ...newAssignment, due_date: e.target.value })}
                      className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Weight (%)</label>
                    <input 
                      type="number" 
                      value={newAssignment.weight}
                      onChange={(e) => setNewAssignment({ ...newAssignment, weight: parseFloat(e.target.value) })}
                      className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Category</label>
                    <select 
                      value={newAssignment.category}
                      onChange={(e) => setNewAssignment({ ...newAssignment, category: e.target.value })}
                      className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    >
                      <option>Assignment</option>
                      <option>Exam</option>
                      <option>Quiz</option>
                      <option>Lab</option>
                      <option>Project</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Priority</label>
                    <select 
                      value={newAssignment.priority}
                      onChange={(e) => setNewAssignment({ ...newAssignment, priority: e.target.value as any })}
                      className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    >
                      <option>Low</option>
                      <option>Medium</option>
                      <option>High</option>
                      <option>Critical</option>
                    </select>
                  </div>
                </div>
                <button 
                  onClick={handleAddAssignment}
                  className="w-full py-4 bg-navy-900 text-white rounded-2xl font-bold hover:bg-navy-800 transition-all mt-4"
                >
                  Create Assignment
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Assignment Modal */}
      <AnimatePresence>
        {isEditModalOpen && editingAssignment && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsEditModalOpen(false)}
              className="absolute inset-0 bg-navy-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl p-8"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-navy-900">Edit Assignment</h3>
                <button onClick={() => setIsEditModalOpen(false)} className="p-2 hover:bg-navy-50 rounded-full">
                  <X size={20} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Name</label>
                  <input 
                    type="text" 
                    value={editingAssignment.name}
                    onChange={(e) => setEditingAssignment({ ...editingAssignment, name: e.target.value })}
                    className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Due Date</label>
                    <input 
                      type="date" 
                      value={editingAssignment.due_date?.split("T")[0]}
                      onChange={(e) => setEditingAssignment({ ...editingAssignment, due_date: e.target.value })}
                      className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Weight (%)</label>
                    <input 
                      type="number" 
                      value={editingAssignment.weight}
                      onChange={(e) => setEditingAssignment({ ...editingAssignment, weight: parseFloat(e.target.value) })}
                      className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Category</label>
                    <select 
                      value={editingAssignment.category}
                      onChange={(e) => setEditingAssignment({ ...editingAssignment, category: e.target.value })}
                      className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    >
                      <option>Assignment</option>
                      <option>Exam</option>
                      <option>Quiz</option>
                      <option>Lab</option>
                      <option>Project</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-navy-400 uppercase mb-1 block">Priority</label>
                    <select 
                      value={editingAssignment.priority}
                      onChange={(e) => setEditingAssignment({ ...editingAssignment, priority: e.target.value as any })}
                      className="w-full p-3 bg-navy-50 rounded-xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900"
                    >
                      <option>Low</option>
                      <option>Medium</option>
                      <option>High</option>
                      <option>Critical</option>
                    </select>
                  </div>
                </div>
                <button 
                  onClick={handleEditAssignment}
                  className="w-full py-4 bg-navy-900 text-white rounded-2xl font-bold hover:bg-navy-800 transition-all mt-4"
                >
                  Save Changes
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Assignment Confirmation Modal */}
      <AnimatePresence>
        {assignmentToDelete && (
          <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setAssignmentToDelete(null)}
              className="absolute inset-0 bg-navy-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-sm rounded-3xl shadow-2xl p-8"
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Trash2 size={32} />
                </div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">Delete Assignment?</h3>
                <p className="text-navy-500 mb-6">
                  Are you sure you want to delete this assignment? This action cannot be undone.
                </p>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setAssignmentToDelete(null)}
                    className="flex-1 py-3 border border-navy-200 text-navy-600 rounded-xl font-bold hover:bg-navy-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => deleteAssignment(assignmentToDelete)}
                    className="flex-1 py-3 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 transition-all"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Class Confirmation Modal */}
      <AnimatePresence>
        {isDeleteModalOpen && (
          <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isDeleting && setIsDeleteModalOpen(false)}
              className="absolute inset-0 bg-navy-900/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl p-8 z-[10000]"
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Trash2 size={32} />
                </div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">Delete Class?</h3>
                <p className="text-navy-500 mb-8">
                  Are you sure you want to delete <span className="font-bold text-navy-900">"{selectedClass?.name}"</span>? 
                  This will permanently remove the class and all its assignments.
                </p>
                <div className="flex gap-4">
                  <button 
                    disabled={isDeleting}
                    onClick={() => setIsDeleteModalOpen(false)}
                    className="flex-1 py-4 border border-navy-200 text-navy-600 rounded-2xl font-bold hover:bg-navy-50 transition-all disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button 
                    disabled={isDeleting}
                    onClick={handleDeleteClass}
                    className="flex-1 py-4 bg-red-500 text-white rounded-2xl font-bold hover:bg-red-600 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isDeleting ? (
                      <>
                        <Loader2 size={20} className="animate-spin" />
                        Deleting...
                      </>
                    ) : (
                      "Delete"
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Assignment List */}
      <div className="space-y-4">
        <AnimatePresence mode="popLayout">
          {classAssignments.map((assignment, idx) => (
            <motion.div
              key={assignment.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: idx * 0.05 }}
              className={`bg-white p-6 rounded-3xl shadow-sm border transition-all flex items-center gap-6 group ${
                assignment.status === "done" ? "border-emerald-100 opacity-75" : "border-navy-100 hover:border-navy-300"
              }`}
            >
              <button 
                onClick={() => toggleStatus(assignment)}
                className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                  assignment.status === "done" 
                    ? "bg-emerald-500 text-white" 
                    : "border-2 border-navy-200 text-transparent hover:border-navy-400"
                }`}
              >
                <CheckCircle size={20} />
              </button>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <div className="flex items-center gap-2">
                    {isAllSelected && (
                      <div 
                        className="w-2 h-2 rounded-full" 
                        style={{ backgroundColor: classes.find(c => c.id === assignment.class_id)?.color }} 
                      />
                    )}
                    <h4 className={`font-bold text-lg truncate ${assignment.status === "done" ? "text-navy-400 line-through" : "text-navy-900"}`}>
                      {assignment.name}
                    </h4>
                  </div>
                  <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider ${
                    assignment.priority === "Critical" ? "bg-red-100 text-red-700" :
                    assignment.priority === "High" ? "bg-orange-100 text-orange-700" :
                    "bg-navy-100 text-navy-700"
                  }`}>
                    {assignment.priority}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
                  <div className="flex items-center gap-2 text-sm text-navy-400">
                    <Calendar size={14} />
                    <span>{safeFormat(assignment.due_date, "MMM d, yyyy", "No date")}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-navy-400">
                    <Clock size={14} />
                    <span>{safeFormat(assignment.due_date, "h:mm a", "No time")}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-navy-400">
                    <span className="font-bold text-navy-600">{assignment.weight}%</span>
                    <span>of grade</span>
                  </div>
                  {assignment.grade !== undefined && assignment.grade !== null && (
                    <div className="flex items-center gap-2 px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-lg text-xs font-bold border border-emerald-100">
                      <Award size={12} />
                      <span>Grade: {assignment.grade}%</span>
                    </div>
                  )}
                  <div className="px-2 py-0.5 bg-navy-50 text-navy-500 rounded-lg text-xs font-medium">
                    {assignment.category || "Assignment"}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {editingGradeId === assignment.id ? (
                  <div className="flex items-center gap-2 bg-navy-50 p-1 rounded-xl border border-navy-200 shadow-inner">
                    <input 
                      autoFocus
                      type="number" 
                      placeholder="Grade %"
                      value={tempGrade}
                      onChange={(e) => setTempGrade(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleSaveGrade(assignment)}
                      className="w-20 px-3 py-1.5 bg-white border border-navy-100 rounded-lg text-sm font-bold focus:outline-none focus:ring-2 focus:ring-navy-900"
                    />
                    <button 
                      onClick={() => handleSaveGrade(assignment)}
                      className="p-1.5 bg-navy-900 text-white rounded-lg hover:bg-navy-800 transition-all"
                    >
                      <Check size={16} />
                    </button>
                    <button 
                      onClick={() => setEditingGradeId(null)}
                      className="p-1.5 text-navy-400 hover:text-navy-600"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => {
                        setEditingGradeId(assignment.id);
                        setTempGrade(assignment.grade?.toString() || "");
                      }}
                      className="p-2 text-navy-400 hover:text-navy-900 hover:bg-navy-50 rounded-xl transition-all"
                      title="Add/Edit Grade"
                    >
                      <Award size={18} />
                    </button>
                    <button 
                      onClick={() => {
                        setEditingAssignment(assignment);
                        setIsEditModalOpen(true);
                      }}
                      className="p-2 text-navy-400 hover:text-navy-900 hover:bg-navy-50 rounded-xl transition-all"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button 
                      onClick={() => setAssignmentToDelete(assignment.id)}
                      className="p-2 text-navy-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {classAssignments.length === 0 && (
          <div className="bg-white p-20 rounded-3xl border border-dashed border-navy-200 text-center">
            <div className="w-16 h-16 bg-navy-50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-navy-300">
              <Circle size={32} />
            </div>
            <h4 className="text-lg font-bold text-navy-900">No assignments found</h4>
            <p className="text-navy-500">Try changing your filter or add a new assignment.</p>
          </div>
        )}
      </div>
    </div>
  );
}
