import { Class, Assignment, Lecture } from "../types";
import { 
  Trophy, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingUp,
  ArrowUpRight
} from "lucide-react";
import { motion } from "motion/react";
import { format, isAfter, isBefore, addDays, isValid } from "date-fns";
import PomodoroTimer from "./PomodoroTimer";
import WorkloadPlanner from "./WorkloadPlanner";

const safeFormat = (dateStr: string | undefined, formatStr: string, fallback: string) => {
  if (!dateStr) return fallback;
  const date = new Date(dateStr);
  if (!isValid(date)) return dateStr;
  return format(date, formatStr);
};

interface GlobalDashboardProps {
  classes: Class[];
  assignments: Assignment[];
  lectures: Lecture[];
  onImportClick: () => void;
}

export default function GlobalDashboard({ classes, assignments, lectures, onImportClick }: GlobalDashboardProps) {
  const upcoming = assignments
    .filter(a => a.status !== "done" && a.due_date)
    .sort((a, b) => {
      const dateA = new Date(a.due_date!).getTime();
      const dateB = new Date(b.due_date!).getTime();
      if (isNaN(dateA)) return 1;
      if (isNaN(dateB)) return -1;
      return dateA - dateB;
    })
    .slice(0, 5);

  const gradedAssignments = assignments.filter(a => a.grade !== undefined && a.grade !== null);
  const totalWeight = gradedAssignments.reduce((acc, a) => acc + (a.weight || 0), 0);
  const weightedScore = gradedAssignments.reduce((acc, a) => acc + ((a.grade || 0) * (a.weight || 0)), 0);
  const avgGrade = totalWeight > 0 ? Math.round(weightedScore / totalWeight) : 0;

  const calculateGPA = (percentage: number) => {
    if (percentage >= 93) return 4.0;
    if (percentage >= 90) return 3.7;
    if (percentage >= 87) return 3.3;
    if (percentage >= 83) return 3.0;
    if (percentage >= 80) return 2.7;
    if (percentage >= 77) return 2.3;
    if (percentage >= 73) return 2.0;
    if (percentage >= 70) return 1.7;
    if (percentage >= 67) return 1.3;
    if (percentage >= 65) return 1.0;
    return 0.0;
  };

  const currentGPA = calculateGPA(avgGrade);

  const stats = [
    { 
      label: "Active Classes", 
      value: classes.length, 
      icon: Trophy, 
      color: "text-blue-600", 
      bg: "bg-blue-50" 
    },
    { 
      label: "Overall GPA", 
      value: avgGrade > 0 ? currentGPA.toFixed(1) : "--", 
      icon: ArrowUpRight, 
      color: "text-emerald-600", 
      bg: "bg-emerald-50" 
    },
    { 
      label: "Completed", 
      value: assignments.filter(a => a.status === "done").length, 
      icon: CheckCircle2, 
      color: "text-emerald-600", 
      bg: "bg-emerald-50" 
    },
    { 
      label: "Avg. Grade", 
      value: avgGrade > 0 ? `${avgGrade}%` : "--", 
      icon: TrendingUp, 
      color: "text-indigo-600", 
      bg: "bg-indigo-50" 
    },
  ];

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-6 rounded-3xl shadow-sm border border-navy-100 flex items-center gap-5"
          >
            <div className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center`}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-navy-400">{stat.label}</p>
              <p className="text-2xl font-bold text-navy-900">{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Upcoming Assignments & Workload */}
        <div className="lg:col-span-2 space-y-8">
          <WorkloadPlanner classes={classes} assignments={assignments} lectures={lectures} />

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-navy-900">Upcoming Deadlines</h3>
              <button className="text-navy-500 text-sm font-semibold hover:text-navy-900 flex items-center gap-1">
                View All <ArrowUpRight size={16} />
              </button>
            </div>

            <div className="space-y-4">
              {upcoming.length > 0 ? upcoming.map((assignment, idx) => {
                const course = classes.find(c => c.id === assignment.class_id);
                return (
                  <motion.div
                    key={assignment.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="bg-white p-5 rounded-3xl shadow-sm border border-navy-100 flex items-center justify-between group hover:border-navy-300 transition-all"
                  >
                    <div className="flex items-center gap-4">
                      <div 
                        className="w-3 h-12 rounded-full" 
                        style={{ backgroundColor: course?.color || "#1e3a8a" }} 
                      />
                      <div>
                        <h4 className="font-bold text-navy-900 group-hover:text-navy-700 transition-colors">
                          {assignment.name}
                        </h4>
                        <p className="text-sm text-navy-400 flex items-center gap-2">
                          <span className="font-semibold text-navy-600">{course?.name}</span>
                          <span>•</span>
                          <span>Due {safeFormat(assignment.due_date, "MMM d, h:mm a", "TBD")}</span>
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        assignment.priority === "Critical" ? "bg-red-50 text-red-600" :
                        assignment.priority === "High" ? "bg-orange-50 text-orange-600" :
                        "bg-navy-50 text-navy-600"
                      }`}>
                        {assignment.priority}
                      </span>
                      <p className="text-xs text-navy-400 mt-1">{assignment.weight}% of grade</p>
                    </div>
                  </motion.div>
                );
              }) : (
                <div className="bg-white p-12 rounded-3xl border border-dashed border-navy-200 text-center">
                  <p className="text-navy-400">No upcoming assignments. Time to relax!</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-8">
          <PomodoroTimer />

          <div className="space-y-6">
            <h3 className="text-xl font-bold text-navy-900">Course Progress</h3>
            <div className="space-y-4">
              {classes.map((course, idx) => {
                const courseAssignments = assignments.filter(a => a.class_id === course.id);
                const completed = courseAssignments.filter(a => a.status === "done").length;
                const total = courseAssignments.length;
                const progress = total > 0 ? (completed / total) * 100 : 0;

                return (
                  <motion.div
                    key={course.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.1 }}
                    className="bg-white p-6 rounded-3xl shadow-sm border border-navy-100"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-bold text-navy-900">{course.name}</h4>
                        <p className="text-xs text-navy-400">{completed}/{total} Tasks Completed</p>
                      </div>
                      <div 
                        className="w-8 h-8 rounded-xl flex items-center justify-center text-white font-bold text-xs"
                        style={{ backgroundColor: course.color }}
                      >
                        {Math.round(progress)}%
                      </div>
                    </div>
                    <div className="w-full h-2 bg-navy-50 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        className="h-full rounded-full"
                        style={{ backgroundColor: course.color }}
                      />
                    </div>
                  </motion.div>
                );
              })}
              
              {classes.length === 0 && (
                <div className="bg-navy-900 text-white p-8 rounded-3xl text-center">
                  <BookOpen size={32} className="mx-auto mb-4 opacity-50" />
                  <h4 className="font-bold mb-2">No Classes Yet</h4>
                  <p className="text-sm text-navy-300 mb-6">Import your first syllabus to get started.</p>
                  <button 
                    onClick={onImportClick}
                    className="w-full py-3 bg-white text-navy-900 rounded-xl font-bold text-sm hover:bg-navy-100 transition-colors"
                  >
                    Import Now
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BookOpen({ size, className }: { size: number, className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M2 3h6a4 4 0 0 1 4 4v14a4 4 0 0 0-4-4H2z" />
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a4 4 0 0 1 4-4h6z" />
    </svg>
  );
}
