import { useState } from "react";
import { Class, Assignment } from "../types";
import { 
  Calculator, 
  Target, 
  TrendingUp, 
  Award,
  Info,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface GradeCalculatorProps {
  classes: Class[];
  assignments: Assignment[];
  onAssignmentsUpdate: () => void;
}

export default function GradeCalculator({ classes, assignments, onAssignmentsUpdate }: GradeCalculatorProps) {
  const [expandedClassId, setExpandedClassId] = useState<string | null>(null);
  const [tempGrades, setTempGrades] = useState<Record<string, number>>({});

  const courseGrades = classes.map(course => {
    const courseAssignments = assignments.filter(a => a.class_id === course.id);
    const gradedAssignments = courseAssignments.filter(a => a.grade !== undefined && a.grade !== null);
    const totalGradedWeight = gradedAssignments.reduce((acc, a) => acc + (a.weight || 0), 0);
    const currentWeightedScore = gradedAssignments.reduce((acc, a) => acc + ((a.grade || 0) * (a.weight || 0)), 0);
    const currentGrade = totalGradedWeight > 0 ? currentWeightedScore / totalGradedWeight : 0;
    return { id: course.id, grade: currentGrade, hasGrades: gradedAssignments.length > 0 };
  });

  const gradedCourses = courseGrades.filter(c => c.hasGrades);
  const overallAverage = gradedCourses.length > 0 
    ? gradedCourses.reduce((acc, c) => acc + c.grade, 0) / gradedCourses.length 
    : 0;
  
  // Simple GPA conversion (4.0 scale)
  const calculateGPA = (percentage: number) => {
    if (percentage >= 93) return 4.0;
    if (percentage >= 90) return 3.7;
    if (percentage >= 87) return 3.3;
    if (percentage >= 83) return 3.0;
    if (percentage >= 80) return 2.7;
    if (percentage >= 77) return 2.3;
    if (percentage >= 73) return 2.0;
    if (percentage >= 70) return 1.7;
    if (percentage >= 67) return 1.3;
    if (percentage >= 65) return 1.0;
    return 0.0;
  };

  const currentGPA = calculateGPA(overallAverage);

  const handleUpdateGrade = async (assignment: Assignment) => {
    const grade = tempGrades[assignment.id];
    if (grade === undefined) return;

    try {
      await fetch(`/api/assignments/${assignment.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...assignment, grade, status: "done" })
      });
      onAssignmentsUpdate();
      setTempGrades(prev => {
        const next = { ...prev };
        delete next[assignment.id];
        return next;
      });
    } catch (error) {
      console.error("Failed to update grade", error);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-navy-900 text-white p-8 rounded-3xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-navy-800 rounded-2xl flex items-center justify-center text-navy-300">
            <Calculator size={32} />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Grade Tracker</h3>
            <p className="text-navy-400">Track your performance and reach your academic goals.</p>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="text-center px-6 py-3 bg-navy-800 rounded-2xl border border-navy-700">
            <p className="text-xs text-navy-400 uppercase font-bold tracking-wider mb-1">Overall GPA</p>
            <p className="text-2xl font-bold">{currentGPA.toFixed(1)}</p>
          </div>
          <div className="text-center px-6 py-3 bg-navy-800 rounded-2xl border border-navy-700">
            <p className="text-xs text-navy-400 uppercase font-bold tracking-wider mb-1">Avg Grade</p>
            <p className="text-2xl font-bold">{overallAverage.toFixed(1)}%</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {classes.map((course, idx) => {
          const courseAssignments = assignments.filter(a => a.class_id === course.id);
          const gradedAssignments = courseAssignments.filter(a => a.grade !== undefined && a.grade !== null);
          
          // Calculate current grade
          const totalGradedWeight = gradedAssignments.reduce((acc, a) => acc + (a.weight || 0), 0);
          const currentWeightedScore = gradedAssignments.reduce((acc, a) => acc + ((a.grade || 0) * (a.weight || 0)), 0);
          const currentGrade = totalGradedWeight > 0 ? currentWeightedScore / totalGradedWeight : 0;
          
          // Calculate what's needed for goal
          const remainingWeight = 100 - totalGradedWeight;
          const goalScore = course.goal_grade || 85;
          const neededScore = remainingWeight > 0 
            ? (goalScore * 100 - currentWeightedScore) / remainingWeight 
            : 0;

          const isExpanded = expandedClassId === course.id;

          return (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-3xl shadow-sm border border-navy-100 overflow-hidden"
            >
              <div 
                className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 cursor-pointer hover:bg-navy-50 transition-colors"
                onClick={() => setExpandedClassId(isExpanded ? null : course.id)}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold" style={{ backgroundColor: course.color }}>
                    {course.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-navy-900">{course.name}</h4>
                    <p className="text-sm text-navy-400">{gradedAssignments.length} graded / {courseAssignments.length} total tasks</p>
                  </div>
                </div>

                <div className="flex items-center gap-8">
                  <div className="text-right">
                    <p className="text-xs text-navy-400 font-bold uppercase tracking-wider mb-1">Current Grade</p>
                    <p className={`text-2xl font-bold ${currentGrade >= 90 ? "text-emerald-600" : currentGrade >= 80 ? "text-navy-900" : "text-amber-600"}`}>
                      {currentGrade.toFixed(1)}%
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-navy-400 font-bold uppercase tracking-wider mb-1">Goal: {goalScore}%</p>
                    <p className="text-sm font-bold text-navy-700">
                      Need {neededScore > 100 ? "100+" : neededScore < 0 ? "0" : neededScore.toFixed(1)}% avg
                    </p>
                  </div>
                  <div className="text-navy-300">
                    {isExpanded ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
                  </div>
                </div>
              </div>

              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="border-t border-navy-100 bg-navy-50/50"
                  >
                    <div className="p-6 space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div className="bg-white p-4 rounded-2xl border border-navy-100 shadow-sm flex items-center gap-4">
                          <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                            <Award size={20} />
                          </div>
                          <div>
                            <p className="text-xs text-navy-400 font-bold">Best Case</p>
                            <p className="font-bold">{( (currentWeightedScore + remainingWeight * 100) / 100 ).toFixed(1)}%</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-2xl border border-navy-100 shadow-sm flex items-center gap-4">
                          <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                            <TrendingUp size={20} />
                          </div>
                          <div>
                            <p className="text-xs text-navy-400 font-bold">Realistic</p>
                            <p className="font-bold">{( (currentWeightedScore + remainingWeight * currentGrade) / 100 ).toFixed(1)}%</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-2xl border border-navy-100 shadow-sm flex items-center gap-4">
                          <div className="w-10 h-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                            <Target size={20} />
                          </div>
                          <div>
                            <p className="text-xs text-navy-400 font-bold">Minimum for Goal</p>
                            <p className="font-bold">{goalScore}%</p>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-sm font-bold text-navy-400 uppercase tracking-wider px-2">Assessment Breakdown</p>
                        {courseAssignments.map(a => (
                          <div key={a.id} className="bg-white p-4 rounded-2xl border border-navy-100 flex items-center justify-between group">
                            <div className="flex items-center gap-4">
                              <div className={`w-2 h-8 rounded-full ${a.grade ? "bg-emerald-400" : "bg-navy-200"}`} />
                              <div>
                                <p className="font-bold text-navy-900">{a.name}</p>
                                <p className="text-xs text-navy-400">{a.category} • {a.weight}% of total</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              {a.grade !== undefined ? (
                                <div className="text-right">
                                  <p className="font-bold text-navy-900">{a.grade}%</p>
                                  <p className="text-[10px] text-emerald-600 font-bold uppercase">Graded</p>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2">
                                  <input 
                                    type="number" 
                                    placeholder="Add grade"
                                    value={tempGrades[a.id] || ""}
                                    onChange={(e) => setTempGrades({ ...tempGrades, [a.id]: parseFloat(e.target.value) })}
                                    className="w-24 px-3 py-1 bg-navy-50 border border-navy-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-navy-900"
                                  />
                                  <button 
                                    onClick={() => handleUpdateGrade(a)}
                                    className="p-1.5 bg-navy-900 text-white rounded-lg hover:bg-navy-800 transition-colors"
                                  >
                                    <Calculator size={14} />
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center gap-2 p-4 bg-blue-50 text-blue-700 rounded-2xl border border-blue-100 mt-4">
                        <Info size={18} />
                        <p className="text-xs font-medium">
                          Calculations assume a standard weighted average system. You can toggle "Drop Lowest Grade" in settings.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
