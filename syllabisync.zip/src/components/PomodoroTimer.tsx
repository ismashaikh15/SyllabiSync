import { useState, useEffect } from "react";
import { Timer, Play, Pause, RotateCcw, Coffee, Brain, Settings as SettingsIcon, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function PomodoroTimer() {
  const [workDuration, setWorkDuration] = useState(25);
  const [breakDuration, setBreakDuration] = useState(5);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<"work" | "break">("work");
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [tempWork, setTempWork] = useState("25");
  const [tempBreak, setTempBreak] = useState("5");

  useEffect(() => {
    let interval: any = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
      // Switch mode
      if (mode === "work") {
        setMode("break");
        setTimeLeft(breakDuration * 60);
      } else {
        setMode("work");
        setTimeLeft(workDuration * 60);
      }
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft, mode, workDuration, breakDuration]);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === "work" ? workDuration * 60 : breakDuration * 60);
  };

  const handleSaveSettings = () => {
    const w = parseInt(tempWork);
    const b = parseInt(tempBreak);
    if (!isNaN(w) && w > 0) setWorkDuration(w);
    if (!isNaN(b) && b > 0) setBreakDuration(b);
    
    setIsSettingsOpen(false);
    setIsActive(false);
    setTimeLeft(mode === "work" ? (isNaN(w) ? workDuration : w) * 60 : (isNaN(b) ? breakDuration : b) * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const currentMaxTime = mode === "work" ? workDuration * 60 : breakDuration * 60;
  const progress = (timeLeft / currentMaxTime) * 100;

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-navy-100">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2 text-navy-900 font-bold">
          <Timer size={20} />
          <span>Focus Timer</span>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsSettingsOpen(!isSettingsOpen)}
            className={`p-1.5 rounded-lg transition-all ${isSettingsOpen ? "bg-navy-100 text-navy-900" : "text-navy-300 hover:text-navy-900 hover:bg-navy-50"}`}
          >
            <SettingsIcon size={16} />
          </button>
          <div className="flex gap-1">
            <button 
              onClick={() => { setMode("work"); setTimeLeft(workDuration * 60); setIsActive(false); }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${mode === "work" ? "bg-navy-900 text-white" : "bg-navy-50 text-navy-400"}`}
            >
              Work
            </button>
            <button 
              onClick={() => { setMode("break"); setTimeLeft(breakDuration * 60); setIsActive(false); }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${mode === "break" ? "bg-navy-900 text-white" : "bg-navy-50 text-navy-400"}`}
            >
              Break
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isSettingsOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden mb-6"
          >
            <div className="p-4 bg-navy-50 rounded-2xl space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-navy-400 uppercase tracking-wider mb-1 block">Work (min)</label>
                  <input 
                    type="number" 
                    value={tempWork}
                    onChange={(e) => setTempWork(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-navy-100 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-navy-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-navy-400 uppercase tracking-wider mb-1 block">Break (min)</label>
                  <input 
                    type="number" 
                    value={tempBreak}
                    onChange={(e) => setTempBreak(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-navy-100 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-navy-900"
                  />
                </div>
              </div>
              <button 
                onClick={handleSaveSettings}
                className="w-full py-2 bg-navy-900 text-white rounded-xl text-xs font-bold hover:bg-navy-800 transition-all flex items-center justify-center gap-2"
              >
                <Check size={14} />
                Apply Durations
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative flex flex-col items-center py-4">
        <div className="relative w-32 h-32 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90">
            <circle 
              cx="64" cy="64" r="60" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="8" 
              className="text-navy-50"
            />
            <motion.circle 
              cx="64" cy="64" r="60" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="8" 
              strokeDasharray="377"
              initial={{ strokeDashoffset: 0 }}
              animate={{ strokeDashoffset: 377 - (377 * (100 - progress)) / 100 }}
              className={mode === "work" ? "text-navy-900" : "text-emerald-500"}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-mono font-bold text-navy-900">{formatTime(timeLeft)}</span>
          </div>
        </div>

        <div className="flex gap-3 mt-8">
          <button 
            onClick={toggleTimer}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-lg ${
              isActive ? "bg-navy-100 text-navy-900" : "bg-navy-900 text-white hover:bg-navy-800"
            }`}
          >
            {isActive ? <Pause size={20} /> : <Play size={20} />}
          </button>
          <button 
            onClick={resetTimer}
            className="w-12 h-12 bg-white border border-navy-100 text-navy-400 rounded-2xl flex items-center justify-center hover:text-navy-900 transition-all shadow-sm"
          >
            <RotateCcw size={20} />
          </button>
        </div>
      </div>

      <div className="mt-6 p-4 bg-navy-50 rounded-2xl flex items-center gap-3">
        {mode === "work" ? (
          <>
            <Brain size={18} className="text-navy-600" />
            <p className="text-xs text-navy-600 font-medium">Deep work mode active. Stay focused!</p>
          </>
        ) : (
          <>
            <Coffee size={18} className="text-emerald-600" />
            <p className="text-xs text-emerald-600 font-medium">Time for a quick break. Stretch a bit!</p>
          </>
        )}
      </div>
    </div>
  );
}
