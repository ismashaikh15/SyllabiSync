import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, FileText, Check, X, Loader2, AlertCircle, PlusCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { extractSyllabusData } from "../services/geminiService";
import { Class, Assignment, SyllabusExtractionResult } from "../types";

interface SyllabusImporterProps {
  onClassAdded: (newClass: Class) => void;
  onClose: () => void;
}

export default function SyllabusImporter({ onClassAdded, onClose, openOverride, setOpenOverride }: SyllabusImporterProps & { openOverride?: boolean, setOpenOverride?: (open: boolean) => void }) {
  const [internalOpen, setInternalOpen] = useState(false);
  const isOpen = openOverride !== undefined ? openOverride : internalOpen;
  const setIsOpen = setOpenOverride !== undefined ? setOpenOverride : setInternalOpen;
  const [step, setStep] = useState<"upload" | "parsing" | "review">("upload");
  const [file, setFile] = useState<File | null>(null);
  const [extractedData, setExtractedData] = useState<SyllabusExtractionResult | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Expose open method to parent if needed, but for now we'll use a ref-like approach or just the fixed button
  // Actually, let's make it controllable from props too if we want, but the current design uses internal state.
  // To allow App.tsx to open it, we should probably lift the state or use a forwardRef.
  // But let's keep it simple: App.tsx can just pass a prop to open it.

  const [textInput, setTextInput] = useState("");

  const handleTextExtract = async () => {
    if (!textInput.trim()) return;
    setIsParsing(true);
    setStep("parsing");
    setError(null);

    try {
      const result = await extractSyllabusData(textInput);
      setExtractedData(result);
      setStep("review");
    } catch (err) {
      console.error(err);
      setError("Failed to extract data from text. Please check your text and try again.");
      setStep("upload");
    } finally {
      setIsParsing(false);
    }
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
      handleParse(acceptedFiles[0]);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
      "text/plain": [".txt"]
    },
    multiple: false
  });

  const handleParse = async (fileToParse: File) => {
    setIsParsing(true);
    setStep("parsing");
    setError(null);

    try {
      const formData = new FormData();
      formData.append("file", fileToParse);

      const response = await fetch("/api/parse-syllabus", {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          const errorData = await response.json();
          throw new Error(errorData.error || "Failed to parse file");
        } else {
          const text = await response.text();
          console.error("Server error (non-JSON):", text);
          throw new Error(`Server error (${response.status}). Please check the console.`);
        }
      }
      
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        const text = await response.text();
        console.error("Unexpected response format:", text);
        throw new Error("Unexpected response from server. Please check the console.");
      }

      const { text } = await response.json();
      const result = await extractSyllabusData(text);
      
      setExtractedData(result);
      setStep("review");
    } catch (err) {
      console.error(err);
      setError("Something went wrong while parsing your syllabus. Please try again or copy-paste the text.");
      setStep("upload");
    } finally {
      setIsParsing(false);
    }
  };

  const handleConfirm = async () => {
    if (!extractedData) return;

    try {
      // 1. Create Class
      const classRes = await fetch("/api/classes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: extractedData.courseName,
          color: "#1e3a8a",
          goal_grade: 85
        })
      });
      const newClass = await classRes.json();

      // 2. Create Assignments
      await Promise.all(extractedData.assignments.map(async (a) => {
        const res = await fetch("/api/assignments", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...a,
            class_id: newClass.id,
            status: "not started",
            priority: "Medium"
          })
        });
        if (!res.ok) throw new Error(`Failed to save assignment: ${a.name}`);
        return res;
      }));

      // 3. Create Lectures
      await Promise.all(extractedData.lectures.map(async (l) => {
        const res = await fetch("/api/lectures", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...l,
            class_id: newClass.id
          })
        });
        if (!res.ok) throw new Error(`Failed to save lecture: ${l.day_of_week}`);
        return res;
      }));

      onClassAdded(newClass);
      setIsOpen(false);
      reset();
    } catch (err) {
      console.error(err);
      setError("Failed to save class data.");
    }
  };

  const reset = () => {
    setStep("upload");
    setFile(null);
    setExtractedData(null);
    setError(null);
    setTextInput("");
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 bg-navy-900 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform z-50 flex items-center gap-2 group"
      >
        <PlusCircle size={24} />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 font-semibold whitespace-nowrap">
          Import Syllabus
        </span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="absolute inset-0 bg-navy-900/40 backdrop-blur-sm"
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-6 overflow-y-auto custom-scrollbar">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold text-navy-900">Import Syllabus</h2>
                  <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-navy-50 rounded-full">
                    <X size={20} />
                  </button>
                </div>

                {step === "upload" && (
                  <div className="space-y-6">
                    <div 
                      {...getRootProps()} 
                      className={`border-2 border-dashed rounded-3xl p-8 text-center transition-all cursor-pointer ${
                        isDragActive ? "border-navy-900 bg-navy-50" : "border-navy-200 hover:border-navy-400"
                      }`}
                    >
                      <input {...getInputProps()} />
                      <div className="bg-navy-100 w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3 text-navy-900">
                        <Upload size={24} />
                      </div>
                      <p className="text-base font-semibold text-navy-900">
                        {isDragActive ? "Drop your syllabus here" : "Click or drag syllabus here"}
                      </p>
                      <p className="text-navy-400 text-xs mt-1">Supports PDF, DOCX, and TXT</p>
                    </div>

                    {error && (
                      <div className="flex items-center gap-3 p-3 bg-red-50 text-red-700 rounded-2xl border border-red-100">
                        <AlertCircle size={18} />
                        <p className="text-xs font-medium">{error}</p>
                      </div>
                    )}

                    <div className="text-center">
                      <p className="text-navy-400 text-xs">Or paste syllabus text below</p>
                      <textarea 
                        className="w-full mt-3 p-3 bg-navy-50 rounded-2xl border border-navy-100 focus:outline-none focus:ring-2 focus:ring-navy-900 min-h-[100px] text-sm"
                        placeholder="Paste syllabus text here..."
                        value={textInput}
                        onChange={(e) => setTextInput(e.target.value)}
                      ></textarea>
                      <button 
                        onClick={handleTextExtract}
                        disabled={!textInput.trim()}
                        className="mt-3 w-full py-3 bg-navy-900 text-white rounded-2xl font-bold hover:bg-navy-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                      >
                        Extract from Text
                      </button>
                    </div>
                  </div>
                )}

                {step === "parsing" && (
                  <div className="py-12 text-center space-y-4">
                    <div className="relative w-16 h-16 mx-auto">
                      <Loader2 size={64} className="text-navy-900 animate-spin" />
                    </div>
                    <h3 className="text-lg font-bold text-navy-900">Analyzing Syllabus</h3>
                    <p className="text-navy-500 text-sm">Gemini is extracting assignments, dates, and weights...</p>
                  </div>
                )}

                {step === "review" && extractedData && (
                  <div className="space-y-5">
                    <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 flex items-start gap-3">
                      <AlertCircle size={18} className="text-blue-600 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-blue-900">Review Extracted Information</p>
                        <p className="text-[10px] text-blue-700 leading-relaxed">
                          We've pulled information to the best of our ability. Please confirm if everything is correct. 
                          <strong> Note:</strong> Assignments with relative dates (e.g., "Week 3") require confirmation.
                        </p>
                      </div>
                    </div>

                    <div className="bg-navy-50 p-4 rounded-2xl border border-navy-100">
                      <p className="text-[10px] font-bold text-navy-400 uppercase tracking-wider mb-1">Course Name</p>
                      <input 
                        type="text" 
                        value={extractedData.courseName}
                        onChange={(e) => setExtractedData({...extractedData, courseName: e.target.value})}
                        className="text-lg font-bold text-navy-900 bg-transparent border-none focus:ring-0 w-full p-0"
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-[10px] font-bold text-navy-400 uppercase tracking-wider">Assignments</p>
                        <button 
                          onClick={() => {
                            const newAssignments = [...extractedData.assignments, { name: "New Assignment", weight: 0, category: "Assignment" }];
                            setExtractedData({...extractedData, assignments: newAssignments});
                          }}
                          className="text-[10px] font-bold text-navy-900 hover:text-navy-700 flex items-center gap-1"
                        >
                          <PlusCircle size={12} /> Add
                        </button>
                      </div>
                      
                      <div className="space-y-2">
                        {extractedData.assignments.map((assignment, idx) => {
                          const isRelative = assignment.due_date?.toLowerCase().includes("week");
                          return (
                            <div key={idx} className={`p-3 bg-white border rounded-2xl shadow-sm transition-all ${isRelative ? "border-orange-100 bg-orange-50/10" : "border-navy-100"}`}>
                              <div className="flex items-start gap-3">
                                <div className="flex-1 min-w-0">
                                  <input 
                                    type="text" 
                                    value={assignment.name}
                                    onChange={(e) => {
                                      const newAssignments = [...extractedData.assignments];
                                      newAssignments[idx].name = e.target.value;
                                      setExtractedData({...extractedData, assignments: newAssignments});
                                    }}
                                    className="font-bold text-navy-900 w-full bg-transparent border-none focus:ring-0 p-0 text-sm"
                                  />
                                  <div className="flex flex-wrap gap-3 mt-1">
                                    <div className="flex items-center gap-1">
                                      <input 
                                        type="text" 
                                        value={assignment.due_date || ""}
                                        placeholder="Due Date"
                                        onChange={(e) => {
                                          const newAssignments = [...extractedData.assignments];
                                          newAssignments[idx].due_date = e.target.value;
                                          setExtractedData({...extractedData, assignments: newAssignments});
                                        }}
                                        className={`text-xs bg-transparent border-none focus:ring-0 p-0 w-28 font-medium ${isRelative ? "text-orange-600" : "text-navy-500"}`}
                                      />
                                      {isRelative && (
                                        <div className="group relative">
                                          <AlertCircle size={12} className="text-orange-500" />
                                          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-32 p-2 bg-navy-900 text-white text-[8px] rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                                            Relative date detected. Please confirm or edit.
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                    <div className="flex items-center gap-1">
                                      <span className="text-[10px] text-navy-400">Weight:</span>
                                      <input 
                                        type="number" 
                                        value={assignment.weight || 0}
                                        onChange={(e) => {
                                          const newAssignments = [...extractedData.assignments];
                                          newAssignments[idx].weight = parseFloat(e.target.value);
                                          setExtractedData({...extractedData, assignments: newAssignments});
                                        }}
                                        className="text-xs font-bold text-navy-700 bg-transparent border-none focus:ring-0 p-0 w-8"
                                      />
                                      <span className="text-[10px] text-navy-400">%</span>
                                    </div>
                                  </div>
                                </div>
                                <button 
                                  onClick={() => {
                                    const newAssignments = extractedData.assignments.filter((_, i) => i !== idx);
                                    setExtractedData({...extractedData, assignments: newAssignments});
                                  }}
                                  className="p-1 text-navy-300 hover:text-red-500 transition-colors"
                                >
                                  <X size={16} />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      <div className="flex items-center justify-between mt-4">
                        <p className="text-[10px] font-bold text-navy-400 uppercase tracking-wider">Lectures</p>
                        <button 
                          onClick={() => {
                            const newLectures = [...extractedData.lectures, { day_of_week: "Monday", start_time: "09:00", end_time: "10:00" }];
                            setExtractedData({...extractedData, lectures: newLectures});
                          }}
                          className="text-[10px] font-bold text-navy-900 hover:text-navy-700 flex items-center gap-1"
                        >
                          <PlusCircle size={12} /> Add
                        </button>
                      </div>
                      
                      <div className="space-y-2">
                        {extractedData.lectures.map((lecture, idx) => (
                          <div key={idx} className="p-3 bg-white border border-navy-100 rounded-2xl shadow-sm">
                            <div className="flex items-start gap-3">
                              <div className="flex-1 min-w-0">
                                <div className="flex gap-2">
                                  <input 
                                    type="text" 
                                    value={lecture.day_of_week}
                                    onChange={(e) => {
                                      const newLectures = [...extractedData.lectures];
                                      newLectures[idx].day_of_week = e.target.value;
                                      setExtractedData({...extractedData, lectures: newLectures});
                                    }}
                                    className="font-bold text-navy-900 w-24 bg-transparent border-none focus:ring-0 p-0 text-sm"
                                  />
                                  <input 
                                    type="text" 
                                    value={lecture.location || ""}
                                    placeholder="Location"
                                    onChange={(e) => {
                                      const newLectures = [...extractedData.lectures];
                                      newLectures[idx].location = e.target.value;
                                      setExtractedData({...extractedData, lectures: newLectures});
                                    }}
                                    className="text-xs text-navy-500 flex-1 bg-transparent border-none focus:ring-0 p-0"
                                  />
                                </div>
                                <div className="flex gap-2 mt-1">
                                  <input 
                                    type="text" 
                                    value={lecture.start_time || ""}
                                    placeholder="Start"
                                    onChange={(e) => {
                                      const newLectures = [...extractedData.lectures];
                                      newLectures[idx].start_time = e.target.value;
                                      setExtractedData({...extractedData, lectures: newLectures});
                                    }}
                                    className="text-[10px] text-navy-500 bg-transparent border-none focus:ring-0 p-0 w-12"
                                  />
                                  <span className="text-[10px] text-navy-400">to</span>
                                  <input 
                                    type="text" 
                                    value={lecture.end_time || ""}
                                    placeholder="End"
                                    onChange={(e) => {
                                      const newLectures = [...extractedData.lectures];
                                      newLectures[idx].end_time = e.target.value;
                                      setExtractedData({...extractedData, lectures: newLectures});
                                    }}
                                    className="text-[10px] text-navy-500 bg-transparent border-none focus:ring-0 p-0 w-12"
                                  />
                                </div>
                              </div>
                              <button 
                                onClick={() => {
                                  const newLectures = extractedData.lectures.filter((_, i) => i !== idx);
                                  setExtractedData({...extractedData, lectures: newLectures});
                                }}
                                className="p-1 text-navy-300 hover:text-red-500 transition-colors"
                              >
                                <X size={16} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-3 pt-2">
                      <button 
                        onClick={reset}
                        className="flex-1 py-3 border border-navy-200 text-navy-600 rounded-2xl font-bold hover:bg-navy-50 transition-all text-sm"
                      >
                        Back
                      </button>
                      <button 
                        onClick={handleConfirm}
                        className="flex-[2] py-3 bg-navy-900 text-white rounded-2xl font-bold hover:bg-navy-800 transition-all flex items-center justify-center gap-2 text-sm"
                      >
                        <Check size={18} />
                        Confirm & Create
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
