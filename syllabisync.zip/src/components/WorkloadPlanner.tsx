import { Class, Assignment, Lecture } from "../types";
import { format, startOfWeek, addDays, isSameDay, isValid, parseISO } from "date-fns";
import { motion } from "motion/react";
import { Clock, MapPin } from "lucide-react";

const safeFormat = (dateStr: string | undefined, formatStr: string, fallback: string) => {
  if (!dateStr) return fallback;
  const date = new Date(dateStr);
  if (!isValid(date)) return dateStr;
  return format(date, formatStr);
};

interface WorkloadPlannerProps {
  classes: Class[];
  assignments: Assignment[];
  lectures: Lecture[];
}

export default function WorkloadPlanner({ classes, assignments, lectures }: WorkloadPlannerProps) {
  const today = new Date();
  const weekStart = startOfWeek(today, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const HOURS = Array.from({ length: 14 }, (_, i) => i + 8); // 8 AM to 9 PM
  const HOUR_HEIGHT = 80;

  const getTimePosition = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(':').map(Number);
    const totalMinutes = (hours - 8) * 60 + minutes;
    return (totalMinutes / 60) * HOUR_HEIGHT;
  };

  const getDurationHeight = (startTime: string, endTime: string) => {
    const [sH, sM] = startTime.split(':').map(Number);
    const [eH, eM] = endTime.split(':').map(Number);
    const durationMinutes = (eH * 60 + eM) - (sH * 60 + sM);
    return (durationMinutes / 60) * HOUR_HEIGHT;
  };

  return (
    <div className="bg-white p-8 rounded-3xl shadow-sm border border-navy-100 overflow-hidden">
      <div className="flex items-center justify-between mb-8">
        <h3 className="text-xl font-bold text-navy-900">Weekly Workload</h3>
        <p className="text-sm text-navy-400 font-medium">Week of {format(weekStart, "MMM d, yyyy")}</p>
      </div>

      <div className="flex">
        {/* Time Legend */}
        <div className="w-16 flex-shrink-0 pt-12">
          {HOURS.map((hour) => (
            <div key={hour} className="h-20 text-[10px] font-bold text-navy-300 text-right pr-3 -mt-2">
              {hour > 12 ? `${hour - 12} PM` : hour === 12 ? "12 PM" : `${hour} AM`}
            </div>
          ))}
        </div>

        {/* Weekly Grid */}
        <div className="flex-1 overflow-x-auto custom-scrollbar">
          <div className="min-w-[700px]">
            <div className="grid grid-cols-7 border-b border-navy-50 mb-4">
              {weekDays.map((day, idx) => {
                const isToday = isSameDay(day, today);
                return (
                  <div key={idx} className="text-center pb-3">
                    <p className={`text-[10px] font-bold uppercase tracking-widest ${isToday ? "text-navy-900" : "text-navy-300"}`}>
                      {format(day, "EEE")}
                    </p>
                    <p className={`text-lg font-bold ${isToday ? "text-navy-900" : "text-navy-400"}`}>
                      {format(day, "d")}
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="relative h-[1120px] grid grid-cols-7">
              {/* Grid Lines */}
              {HOURS.map((hour, idx) => (
                <div 
                  key={hour} 
                  className="absolute left-0 right-0 border-t border-navy-50/50"
                  style={{ top: `${idx * HOUR_HEIGHT}px` }}
                />
              ))}
              
              {/* Vertical Dividers */}
              {Array.from({ length: 8 }).map((_, i) => (
                <div 
                  key={i} 
                  className="absolute top-0 bottom-0 border-l border-navy-50/50"
                  style={{ left: `${(i / 7) * 100}%` }}
                />
              ))}

              {/* Content Columns */}
              {weekDays.map((day, dayIdx) => {
                const dayName = format(day, "EEEE");
                const dayLectures = lectures.filter(l => l.day_of_week === dayName);
                const dayAssignments = assignments.filter(a => {
                  if (!a.due_date) return false;
                  let d = parseISO(a.due_date);
                  if (!isValid(d)) {
                    d = new Date(a.due_date);
                  }
                  return isValid(d) && isSameDay(d, day);
                });

                return (
                  <div key={dayIdx} className="relative h-full">
                    {/* Lectures */}
                    {dayLectures.map((lecture) => {
                      const course = classes.find(c => c.id === lecture.class_id);
                      const top = getTimePosition(lecture.start_time);
                      const height = getDurationHeight(lecture.start_time, lecture.end_time);
                      
                      return (
                        <motion.div
                          key={lecture.id}
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="absolute left-1 right-1 rounded-xl p-2 text-[9px] font-bold shadow-sm overflow-hidden border border-white/20"
                          style={{ 
                            top: `${top}px`, 
                            height: `${height}px`,
                            backgroundColor: course?.color,
                            color: 'white'
                          }}
                        >
                          <p className="truncate">{course?.name}</p>
                          <p className="opacity-80 text-[8px]">{lecture.start_time} - {lecture.end_time}</p>
                          {height > 40 && lecture.location && (
                            <div className="flex items-center gap-1 mt-1 opacity-70">
                              <MapPin size={8} />
                              <span className="truncate">{lecture.location}</span>
                            </div>
                          )}
                        </motion.div>
                      );
                    })}

                    {/* Assignments (placed at their due time, or stacked if no time) */}
                    {dayAssignments.map((assignment, aIdx) => {
                      const course = classes.find(c => c.id === assignment.class_id);
                      const d = parseISO(assignment.due_date);
                      const date = isValid(d) ? d : new Date(assignment.due_date);
                      const timeStr = isValid(date) ? format(date, "HH:mm") : "09:00";
                      const top = getTimePosition(timeStr);

                      return (
                        <motion.div
                          key={assignment.id}
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="absolute left-2 right-2 rounded-lg p-1.5 text-[8px] font-bold shadow-md border-l-4 z-10"
                          style={{ 
                            top: `${top}px`,
                            backgroundColor: 'white',
                            color: course?.color,
                            borderLeftColor: course?.color,
                            boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
                          }}
                        >
                          <div className="flex items-center gap-1">
                            <Clock size={8} />
                            <span className="truncate">{assignment.name}</span>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
