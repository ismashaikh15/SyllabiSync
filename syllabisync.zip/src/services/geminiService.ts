import { GoogleGenAI, Type } from "@google/genai";
import { SyllabusExtractionResult } from "../types";

const apiKey = process.env.GEMINI_API_KEY || "";
if (!apiKey) {
  console.warn("GEMINI_API_KEY is not set. Syllabus extraction will fail.");
}
const ai = new GoogleGenAI({ apiKey });

export async function extractSyllabusData(text: string): Promise<SyllabusExtractionResult> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Extract course information, all assignments/important dates, and the regular lecture/class schedule from the following syllabus text. 
    
    IMPORTANT: Some syllabi have non-standard layouts. Information might be scattered. 
    - Look for assignment weights in grade tables, but look for due dates in the detailed assignment descriptions later in the text.
    - If a due date is relative (e.g., "Week 3", "End of Week 2"), extract it exactly as written.
    - If a specific time is mentioned (e.g., "by 6pm"), include it in the due_date string.
    - Ensure all assignments mentioned in the grading section are captured, even if details are elsewhere.
    
    For assignments: Include names, due dates (MANDATORY: Use ISO 8601 format YYYY-MM-DDTHH:mm:ss if possible, otherwise descriptive like "2026-03-15"), weights (%), and categories.
    
    For lectures: Include the days of the week (e.g., Monday, Wednesday), start time (24h HH:mm), end time (24h HH:mm), and location if mentioned.
    
    Syllabus Text:
    ${text}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          courseName: { type: Type.STRING },
          assignments: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                due_date: { type: Type.STRING, description: "ISO date string or descriptive string like 'Week 6'" },
                weight: { type: Type.NUMBER },
                category: { type: Type.STRING },
              },
              required: ["name"]
            }
          },
          lectures: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                day_of_week: { type: Type.STRING, description: "Full day name, e.g., Monday" },
                start_time: { type: Type.STRING, description: "24h format HH:mm" },
                end_time: { type: Type.STRING, description: "24h format HH:mm" },
                location: { type: Type.STRING }
              },
              required: ["day_of_week", "start_time", "end_time"]
            }
          }
        },
        required: ["courseName", "assignments", "lectures"]
      }
    }
  });

  try {
    return JSON.parse(response.text || "{}") as SyllabusExtractionResult;
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Failed to extract syllabus data");
  }
}
