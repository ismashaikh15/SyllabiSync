export interface Class {
  id: string;
  name: string;
  color: string;
  goal_grade: number;
}

export interface Assignment {
  id: string;
  class_id: string;
  name: string;
  due_date: string; // ISO string
  weight: number; // percentage
  category: string;
  status: 'not started' | 'in progress' | 'done';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  estimated_time?: number; // hours
  difficulty?: number; // 1-5
  grade?: number; // percentage
}

export interface Lecture {
  id: string;
  class_id: string;
  day_of_week: string; // 'Monday', 'Tuesday', etc.
  start_time: string; // 'HH:mm'
  end_time: string; // 'HH:mm'
  location?: string;
}

export interface SyllabusExtractionResult {
  courseName: string;
  assignments: Partial<Assignment>[];
  lectures: Partial<Lecture>[];
}
